function e(e){return String(e||``).replace(/&nbsp;|&#160;|&#xA0;/gi,` `).replace(/&amp;/gi,`&`).replace(/&lt;/gi,`<`).replace(/&gt;/gi,`>`).replace(/&quot;/gi,`"`).replace(/&#39;|&apos;/gi,`'`).replace(/&#(\d+);/g,(e,t)=>{let n=Number(t);return Number.isFinite(n)?String.fromCharCode(n):``}).replace(/&#x([0-9a-f]+);/gi,(e,t)=>{let n=parseInt(t,16);return Number.isFinite(n)?String.fromCharCode(n):``})}var t=[/^\s*window\.[A-Za-z_$][\w$]*\s*=\s*["'][A-Za-z0-9+/=\s]{40,}["'];?\s*$/gim];function n(n){let r=String(n||``).replace(/<\s*br\s*\/?\s*>/gi,`
`).replace(/<\/\s*p\s*>/gi,`
`).replace(/<\s*p\b[^>]*>/gi,`
`).replace(/<\/\s*div\s*>/gi,`
`).replace(/<\s*div\b[^>]*>/gi,`
`).replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,``).replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,``).replace(/<[^>]+>/g,``);r=e(r);for(let e of t)r=r.replace(e,``);return r.split(`
`).map(e=>e.replace(/[ \t\f\v]+/g,` `).trim()).join(`
`).replace(/\n{3,}/g,`

`).trim()}export{n as t};